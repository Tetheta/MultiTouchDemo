To run:
Start up touchDemo.html using Google Chrome. It doesn't work well (or at all) in other browsers.

To replace the images:
Name the new images Demo1.png etc, and delete or rename the current ones.
This does unfortunately mean that .jpg and other image formats are not as easily supported. 

If you want to use a different file name or extension, edit the demoImage variable in touchDemo.js as well as the .css file,
just look at the bottom under #img1 etc and change the image links there.
